# UwU Text

## By NoPro2024#4065

* This is a small resource pack for Minecraft 1.16.2 to 1.16.5.
* To install, drag the folder/.zip file into `.minecraft/resourcepacks` as you would with any other resource pack.
* This pack replaces most occurences of the letters "l" or "r" with "w".
* Some texts, such as the copyright message, are not able to be changed through resource packs and are therefore unchanged.
* The Minecraft logo on the title screen is not changed, nor is the Minecraft Realms logo.
* All files in the pack are modified versions of files from the Minecraft jar.
* The file `en_us.json` was modified through a Python script, while the other 3 files were modified through Find and Replace in VS Code, with some manual edits.

UwU
